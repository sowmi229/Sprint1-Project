package com.flight.entities;

import java.util.Objects;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "flight")
public class Flight {

	@OneToOne(mappedBy = "flight")
	@JsonIgnore
	private FlightDetails flightdetails;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "flightid")
	private int flightId;
	@Column(name = "flightname")
	private String flightName;
	@Column(name = "fare")
	private int fare;

	public Flight() {
		super();
	}

	public Flight(int flightId, String flightName, int fare) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.fare = fare;
	}

	public FlightDetails getFlightdetails() {
		return flightdetails;
	}

	public void setFlightdetails(FlightDetails flightdetails) {
		this.flightdetails = flightdetails;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	@Override
	public String toString() {
		return "Flight [flightdetails=" + flightdetails + ", flightId=" + flightId + ", flightName=" + flightName
				+ ", fare=" + fare + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(fare, flightId, flightName, flightdetails);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		return fare == other.fare && flightId == other.flightId && Objects.equals(flightName, other.flightName)
				&& Objects.equals(flightdetails, other.flightdetails);
	}

	

}
