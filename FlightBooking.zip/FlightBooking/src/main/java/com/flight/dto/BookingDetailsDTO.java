package com.flight.dto;

import java.util.List;
import com.flight.entities.Flight;
import com.flight.entities.Passenger;

public class BookingDetailsDTO {

	private int bookingId;
	private Flight flight;
	private List<Passenger> passenger;

	public BookingDetailsDTO() {
		super();
	}

	public BookingDetailsDTO(int bookingId, Flight flight, List<Passenger> passenger) {
		super();
		this.bookingId = bookingId;
		this.flight = flight;
		this.passenger = passenger;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public List<Passenger> getPassenger() {
		return passenger;
	}

	public void setPassenger(List<Passenger> passenger) {
		this.passenger = passenger;
	}

	@Override
	public String toString() {
		return "BookingDetailsDTO [bookingId=" + bookingId + ", flight=" + flight + ", passenger=" + passenger + "]";
	}

}
