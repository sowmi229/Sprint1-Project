package com.flight.dto;

import com.flight.entities.FlightDetails;

public class FlightDTO {
	
	FlightDetails flightdetails;
	private int flightId;
	private String flightName;
	private int fare;

	public FlightDTO() {
		super();
	}

	public FlightDTO(int flightId, String flightName, int fare) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.fare = fare;
	}

	public FlightDetails getFlightdetails() {
		return flightdetails;
	}

	public void setFlightdetails(FlightDetails flightdetails) {
		this.flightdetails = flightdetails;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	@Override
	public String toString() {
		return "FlightDTO [flightdetails=" + flightdetails + ", flightId=" + flightId + ", flightName=" + flightName
				+ ", fare=" + fare + "]";
	}

}
