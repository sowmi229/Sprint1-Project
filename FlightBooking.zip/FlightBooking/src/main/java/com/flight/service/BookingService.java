package com.flight.service;

import java.time.LocalDate;
import java.util.List;

import com.flight.dto.BookingDTO;
import com.flight.entities.BookingDetails;
import com.flight.exceptions.BookingNotFoundException;

public interface BookingService {
	
	public List<BookingDTO> getAllBooking();

	public BookingDTO getBookingById(Integer bookingId) throws BookingNotFoundException;

	public Integer addBooking(BookingDTO booking);

	public void updateBooking(Integer bookingId, LocalDate bookingDate, LocalDate travelDate, String flightStatus,
			int totalCost) throws BookingNotFoundException;

	public void deleteBookingById(Integer bookingId);
	
	public BookingDetails addBookingDetails(BookingDetails bookingDetails);
}
